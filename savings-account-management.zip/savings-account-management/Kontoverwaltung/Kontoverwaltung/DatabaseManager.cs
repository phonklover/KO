﻿using MySql.Data.MySqlClient;
using System;
using System.Data.SqlClient;

namespace Kontoverwaltung.Database
{
    public class DatabaseManager
    {
        private static DatabaseManager _instance;
        private MySqlConnection _connection;
        private string _connectionString = "server=127.0.0.1;port=3306;database=Kontoverwaltung;uid=root;pwd=odkopkwd;";

        public static DatabaseManager Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new DatabaseManager();
                }
                return _instance;
            }
        }

        private DatabaseManager()
        {
            _connection = new MySqlConnection(_connectionString);
        }

        public MySqlConnection GetConnection()
        {
            return _connection;
        }

    }
}