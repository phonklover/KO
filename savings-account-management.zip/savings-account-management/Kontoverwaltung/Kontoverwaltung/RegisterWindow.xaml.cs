﻿using System.Windows;

namespace Kontoverwaltung
{
    public partial class RegisterWindow : BaseWindow
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }
    }
}
