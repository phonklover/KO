﻿using System.Windows;

namespace Kontoverwaltung
{
    public partial class LoginWindow : BaseWindow
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
    }
}
