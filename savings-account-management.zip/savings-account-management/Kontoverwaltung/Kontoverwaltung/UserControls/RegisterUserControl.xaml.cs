﻿using System;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows;
using System.Text.RegularExpressions;
using Kontoverwaltung.Database;
using MySql.Data.MySqlClient;
using Kontoverwaltung.UserControls;
using System.Data.SqlClient;

namespace Kontoverwaltung
{
    public partial class RegisterUserControl : UserControl
    {
        private MainWindow parent;
        public RegisterUserControl(MainWindow parent)
        {
            this.parent = parent;
            InitializeComponent();
            PopulateDayComboBox();
            PopulateMonthComboBox();
            PopulateYearComboBox();
        }

        private void PopulateDayComboBox()
        {
            for (int day = 1; day <= 31; day++)
            {
                dayComboBox.Items.Add(day);
            }
        }

        private void PopulateMonthComboBox()
        {
            var months = System.Globalization.DateTimeFormatInfo.InvariantInfo.MonthNames;
            foreach (string month in months)
            {
                if (!string.IsNullOrEmpty(month))
                {
                    monthComboBox.Items.Add(month);
                }
            }
        }

        private void PopulateYearComboBox()
        {
            int startYear = DateTime.Now.Year - 17;
            int endYear = startYear - 100;

            for (int year = startYear; year >= endYear; year--)
            {
                yearComboBox.Items.Add(year);
            }
        }

        private void FirstNameField_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateName(FirstNameField);
        }

        private void LastNameField_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateName(LastNameField);
        }

        private void AdressField_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateAddress(AddressField);
        }

        private void ValidateName(TextBox textBox)
        {
            if (!Regex.IsMatch(textBox.Text, @"^[a-zA-Z\s]*$"))
                textBox.Foreground = Brushes.Red;
            else
                textBox.Foreground = Brushes.Black;
        }

        private void ValidateAddress(TextBox textBox)
        {
            if (!Regex.IsMatch(textBox.Text, @"^[a-zA-Z0-9\s/,]*$"))
                textBox.Foreground = Brushes.Red;
            else
                textBox.Foreground = Brushes.Black;
        }

        private bool ConfirmAge()
        {
            if (dayComboBox.SelectedItem == null || monthComboBox.SelectedItem == null || yearComboBox.SelectedItem == null)
                return false;

            DateTime selectedDate = new DateTime((int)yearComboBox.SelectedItem, monthComboBox.SelectedIndex + 1, (int)dayComboBox.SelectedItem);
            DateTime today = DateTime.Today;
            TimeSpan age = today - selectedDate;

            if (age.TotalDays / 365.25 < 18)
            {
                dayComboBox.Foreground = Brushes.Red;
                monthComboBox.Foreground = Brushes.Red;
                yearComboBox.Foreground = Brushes.Red;
                return false;
            }
            else
            {
                dayComboBox.Foreground = Brushes.Black;
                monthComboBox.Foreground = Brushes.Black;
                yearComboBox.Foreground = Brushes.Black;
                return true;
            }
        }

        private bool ValidatePassportNumber(string passportNumber)
        {
            Regex regex = new Regex(@"^[a-zA-Z][^BO]{5,7}$");
            return regex.IsMatch(passportNumber);
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ConfirmAge())
            {
                MessageBox.Show("You must be at least 18 years old to register.");
                return;
            }

            if (!ValidatePassportNumber(PassportNumberField.Text))
            {
                MessageBox.Show("Invalid Passport Number. It must start with a letter, be between 6 to 8 characters, and not contain 'B' or 'O'.");
                return;
            }

            try
            {
                DatabaseManager.Instance.GetConnection().Open();

                MySqlCommand cmd = new MySqlCommand("INSERT INTO users (FirstName, LastName, Address, BirthDate, PassportNumber) VALUES (@FirstName, @LastName, @Address, @BirthDate, @PassportNumber)", DatabaseManager.Instance.GetConnection());

                cmd.Parameters.AddWithValue("@FirstName", FirstNameField.Text);
                cmd.Parameters.AddWithValue("@LastName", LastNameField.Text);
                cmd.Parameters.AddWithValue("@Address", AddressField.Text);
                cmd.Parameters.AddWithValue("@BirthDate", new DateTime((int)yearComboBox.SelectedItem, monthComboBox.SelectedIndex + 1, (int)dayComboBox.SelectedItem));
                cmd.Parameters.AddWithValue("@PassportNumber", PassportNumberField.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Registration successful.");

                DatabaseManager.Instance.GetConnection().Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while registering: " + ex.Message);
                DatabaseManager.Instance.GetConnection().Close();
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.parent.SetUserControl(new MainUserControl(parent));
        }
    }
}