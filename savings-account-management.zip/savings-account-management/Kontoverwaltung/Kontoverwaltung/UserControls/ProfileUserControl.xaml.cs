﻿using System.Windows;

namespace Kontoverwaltung.UserControls
{
    public partial class ProfileUserControl : Window
    {
        public ProfileUserControl()
        {
            InitializeComponent();
        }
    }
}
