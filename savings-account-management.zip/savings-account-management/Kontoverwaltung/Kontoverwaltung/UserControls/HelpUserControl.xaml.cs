﻿using Kontoverwaltung.UserControls;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Kontoverwaltung
{
    public partial class HelpUserControl : UserControl
    {
        private MainWindow parent;

        public HelpUserControl(MainWindow parent)
        {
            this.parent = parent;
            InitializeComponent();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            parent.SetUserControl(new MainUserControl(parent));
        }

        private void DeleteFromPersonalNumberField_Click(object sender, RoutedEventArgs e)
        {
            FamilyNameTextBox.Clear();
        }

        private void DeleteFromPassportNumberField_Click(object sender, RoutedEventArgs e)
        {
            PassportNumberTextBox.Clear();
        }

        private void ForgotAccountNumber_Click(object sender, RoutedEventArgs e)
        {
            InfoTextBox_Copy.Text = "This is your new account number to log in.";
            InfoTextBox_Copy.FontSize = 20;
            InfoTextBox_Copy.FontWeight = FontWeights.Bold;
            InfoTextBox_Copy.Foreground = Brushes.White;
            InfoTextBox_Copy.Opacity = 1; 
            InfoTextBox_Copy.Visibility = Visibility.Visible;
        }

        private void ForgotPIN_Click(object sender, RoutedEventArgs e)
        {
            InfoTextBox_Copy.Text = "This is your new PIN code for the log in.";
            InfoTextBox_Copy.FontSize = 20;
            InfoTextBox_Copy.FontWeight = FontWeights.Bold;
            InfoTextBox_Copy.Foreground = Brushes.White;
            InfoTextBox_Copy.Opacity = 1; 
            InfoTextBox_Copy.Visibility = Visibility.Visible;
        }
    }
}